# Lab 1 - Modelling of Dynamical Systems EL2820

The first lab of EL2820 is made up of two assignments. The instructions for the assignments can be found in the notebooks (i.e. `.ipynb` files) of the `/assignment1` and `/assignment2` folders respectively. Note that the assignments are due on different dates, so make sure to complete the first before proceeding with the second.

To install the required dependencies, you will use `conda`. `conda` is one of the most popular package management systems for Python, and is relatively easy to use. There are two main versions to choose from: A light-weight version called `Miniconda`, ([link to webpage](https://docs.conda.io/en/latest/miniconda.html)) or Anaconda ([link to webpage](https://www.anaconda.com/products/distribution)). Anaconda automatically installs more packages than you'll need, and hence takes up much more disk space. It is, however, more user-friendly. so choose a version that makes sense for you! Please, follow the installation guidelines on the respective webpage to install `conda` on your computer. After `conda` has been installed, go through the following steps to install setup all you'll need for the lab.

1. **Download the repository**. Download Lab 1 from canvas and unzip it.
2. **Install dependencies in a conda environment**: Open the folder and open a terminal in the current directory. Given that conda has been installed correctly, the path should have `(base)` as a prefix, i.e. the prompt should be something like `(base) user-name:~/courses/EL2820/LAB1/`.  Run the following commands:

```
    conda env create
```
to create a conda environment with the right dependencies, followed by:

```
    conda activate EL2820
``` 

to activate it. Congrats - you now have everything you need (at least in terms of software requirements) for the first lab! Note that the prefix is now "EL2820", instead of "base". 

3. **Open a notebook with lab instructions**. To open `jupyter`, simply run 

```
    jupyter-notebook .
```
this will run jupyter on local-host, accessible via the browser, which will automatically be open after executing `jupyter-notebook .`. Press the assignment folder of interest and click the respective notebook (`acrobot.ipynb` for assignment1, and `transmission_lines.ipynb` for assignment 2). To exit Jupyter, press `CTRL` + `C` in the terminal to kill the session. To exit the environment, run:

```
    conda deactivate
```
in your terminal, which will reopen the `base` environment. If you're interested in learning more about `conda`, we refer to the extensive material provided by conda, e.g. their the [Conda cheat sheet](https://docs.conda.io/projects/conda/en/4.6.0/_downloads/52a95608c49671267e40c689e0bc00ca/conda-cheatsheet.pdf).

## Submission guidelines

#### Assignment 1: Modeling and control for Acrobot
Complete the tasks in the notebook by following the provided instructions. To submit, simply upload the notebook `acrobot.ipynb` on canvas no later than 2022-09-09. To facilitate the grading, please **don't** rename the file.

#### Assignment 2: A transmission line
Complete the tasks in the notebook by following the provided instructions. To submit, simply upload the notebook `transmission_line.ipynb` on canvas no later than 2022-09-16. To facilitate the grading, please **don't** rename the file.