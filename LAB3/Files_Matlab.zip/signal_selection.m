clear variables;
load lab3_data\white_noise_1.mat;
Ts = 0.001;

y = y;
N = length(y);
fs = 1/Ts;
df = fs / N;
f = 0:df:(fs/2-df);
Y = abs(fft(y - mean(y)));
plot(f, Y(1:N/2));
xlim([0 3]);
% alpha = 0.25;
