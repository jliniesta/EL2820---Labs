function bar_y = getStationaryAverages(y_step, Nwr, tail)
bar_y = zeros(Nwr, 1);

length_step = length(y_step)/Nwr;
for i = 1:Nwr
    y_part = y_step((i-1)*length_step+1:i*length_step);
    bar_y(i) = getAverage(y_part, tail);
end
end