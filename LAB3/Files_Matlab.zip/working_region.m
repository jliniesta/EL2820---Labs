load lab3_data\working_region.mat;
Nwr = 21;
tail = 75;
y_average = getStationaryAverages(y, Nwr, tail);
u_average = getStationaryAverages(u, Nwr, 10);
plot(u_average, y_average);
% working region: u=1.5, 4