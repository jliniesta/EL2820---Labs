function bar_v = getAverage(v, tail)
tail_abs = floor(length(v) * tail / 100);
v_tail = v(end - (tail_abs - 1):end, 1);
bar_v = mean(v_tail);

end

